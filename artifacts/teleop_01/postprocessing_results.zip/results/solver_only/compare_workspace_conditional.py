"""Compare the requested normalized Solver call on the fixed 599-frame motion."""

import json
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from plot_solver_results import configure_style, BLUE, ORANGE, GREEN, RED, AMBER

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT/'DHandControl/scripts'))
from mh6_palm_solver_v2 import MH6PalmSolver
from mh6_palm_calibration import PALM_MOTOR_SAFE_LIMITS


def valid_motor(motor):
    return motor is not None and all(PALM_MOTOR_SAFE_LIMITS[k][0] <= value <= PALM_MOTOR_SAFE_LIMITS[k][1]
                                    for k, value in enumerate(motor, 1))


def read_rows(path):
    return [json.loads(l) for l in path.read_text().splitlines() if l.strip()]


def main():
    baseline = read_rows(HERE/'teleop_01_axis_corrected.jsonl')
    conditional = read_rows(HERE/'teleop_01_workspace_conditional.jsonl')
    assert len(baseline) == len(conditional) == 599
    solver = MH6PalmSolver()
    last_motor = None
    history = []
    with (HERE/'teleop_01_workspace_conditional_history.jsonl').open('w') as output:
        for old, new in zip(baseline, conditional):
            assert old['frame_index'] == new['frame_index'] and old['timestamp'] == new['timestamp']
            assert old['raw_mapping'] == new['raw_mapping']
            old_adapter, adapter = old['solver']['adapter'], new['solver']['adapter']
            assert old_adapter['workspace_input'] == adapter['workspace_input']
            assert adapter['mapping_mode'] == 'workspace_conditional'
            assert adapter['solver_entrypoint'] == 'solve_motor_safe_from_normalized'
            u1, u2, u3 = (adapter['workspace_input'][key] for key in ('u1', 'u2', 'u3'))
            previous = last_motor
            result = solver.solve_motor_safe_from_normalized(
                u1, u2, u3,
                mode='workspace_conditional',
                previous_motor=last_motor,
                project_invalid=False,
                motor_order='timeseries',
            )
            candidates = result['solutions'] + [solver.reorder_motor_solution(row, motor_order='timeseries')
                                                 for row in result['rejected_motor_solutions']]
            assert candidates == new['solver']['candidates']
            assert result['requested_angles'] == adapter['requested_angles']
            assert not result['projected'] and result['requested_angles'] == result['used_angles']
            row = {'frame_index': new['frame_index'], 'timestamp': new['timestamp'],
                   'normalized_input_u1_u2_u3': [u1, u2, u3], 'previous_motor': previous,
                   'motor_order': [1, 2, 3], 'result': result,
                   'core_selected_satisfies_actual_motor_limits': valid_motor(result['selected']),
                   'has_any_actual_motor_solution': any(valid_motor(motor) for motor in candidates)}
            history.append(row)
            output.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')
            if result['selected'] is not None:
                last_motor = result['selected']
    t = np.array([r['timestamp'] for r in conditional])
    curls = np.array([[r['raw_mapping']['curl_norm'][f] for f in ('index', 'middle', 'ring', 'little')]
                      for r in conditional])
    distances = np.array([[r['raw_mapping']['opposition_distances'][f] for f in ('index', 'middle', 'ring', 'little')]
                          for r in conditional])
    fist = ((t < 9.5) | ((t >= 17.5) & (t < 25.5))) & (curls.mean(axis=1) >= .8)
    masks = {'all': np.ones(len(t), dtype=bool), 'strong_fist_proxy': fist}
    for j, (name, (low, high)) in enumerate(zip(('index', 'middle', 'ring', 'little'),
                                               ((9.7, 11), (11.5, 12.7), (13, 14.4), (15.2, 16.5)))):
        masks[name+'_opposition_core'] = (t >= low) & (t <= high) & (distances[:, j] < .02) & (distances.argmin(axis=1) == j)
    masks['all_opposition_cores'] = np.any([masks[k+'_opposition_core'] for k in ('index', 'middle', 'ring', 'little')], axis=0)
    masks['thumb_measured_plus_one'] = np.array([r['raw_mapping']['palm_command']['thumb_rotation_measured'] == 1 for r in conditional])
    summary = {
        'experiment': 'Only replace the normalized-to-angle mapping with workspace_conditional; original hand mapping, weights, and u1/u2/u3 are identical.',
        'baseline_log': str(HERE/'teleop_01_axis_corrected.jsonl'),
        'conditional_log': str(HERE/'teleop_01_workspace_conditional.jsonl'),
        'with_history_log': str(HERE/'teleop_01_workspace_conditional_history.jsonl'),
        'input_order': ['vertical', 'thumb_rotation_command', 'lateral'],
        'angle_order': ['alpha2', 'alpha3', 'theta1'],
        'new_solver_call': 'solve_motor_safe_from_normalized(u1, u2, u3, mode="workspace_conditional", previous_motor=last_motor, project_invalid=False, motor_order="timeseries")',
        'frame_comparison': 'All 599 raw mapping outputs and all normalized inputs match baseline exactly. Carrying last_motor changes branch selection only; all candidate lists match independent per-frame replay exactly.',
        'projection_frames': sum(r['result']['projected'] for r in history),
        'core_success_frames_with_default_0_1000_bounds': sum(r['result']['success'] for r in history),
        'core_selected_frames_with_actual_motor_limits': sum(r['core_selected_satisfies_actual_motor_limits'] for r in history),
        'some_valid_branch_but_selected_branch_rejected_frames': sum(r['has_any_actual_motor_solution'] and not r['core_selected_satisfies_actual_motor_limits'] for r in history),
        'neutral_input_u1_u2_u3': [31.1/121.9, 59/239, 8.6/32.3],
        'neutral_requested_angles_deg': list(solver.map_normalized(31.1/121.9, 59/239, 8.6/32.3, mode='workspace_conditional')),
        'interpretation': 'Conditional mapping constructs a feasible angle target before solving. project_invalid=false disables post-mapping projection; it does not preserve the old motor-range angle target. Input gesture identity is unchanged, but robot-pose fidelity has not been validated.',
        'phase_criteria': 'Same human-only proxy criteria as intent_audit: mean long-finger curl>=0.8 for strong fist; target distance<20mm and nearest finger for completed opposition.',
        'phases': {},
    }
    for name, mask in masks.items():
        summary['phases'][name] = {'frames': int(mask.sum())}
        for label, rows in [('baseline', baseline), ('conditional', conditional)]:
            chosen = [r['solver'] for i, r in enumerate(rows) if mask[i]]
            summary['phases'][name][label] = {'geometry_solved_frames': sum(r['has_solution'] for r in chosen),
                                             'valid_motor_frames': sum(r['has_valid_motor_solution'] for r in chosen)}
    angles = {name: np.array([r['solver']['requested_angles'] for r in rows]) for name, rows in [('baseline', baseline), ('conditional', conditional)]}
    summary['actual_angle_ranges_deg'] = {name: {'min': a.min(axis=0).tolist(), 'max': a.max(axis=0).tolist()} for name, a in angles.items()}
    (HERE/'teleop_01_workspace_conditional_comparison.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    configure_style()
    fig, axes = plt.subplots(4, 1, figsize=(14, 10), sharex=True, gridspec_kw={'height_ratios': [1, 1, 1, .65]})
    for axis, label in enumerate(('上下翻折 α2（度）', '拇指旋转 α3（度）', '左右翻折 θ1（度）')):
        axes[axis].plot(t, angles['baseline'][:, axis], color='#84919E', label='原角度映射', linewidth=1.2)
        axes[axis].plot(t, angles['conditional'][:, axis], color=BLUE, label='workspace_conditional', linewidth=1.2)
        axes[axis].set_ylabel(label); axes[axis].grid(True)
    axes[0].legend(loc='upper right', ncol=2)
    states = np.array([[2 if r['solver']['has_valid_motor_solution'] else 1 if r['solver']['has_solution'] else 0 for r in rows]
                       for rows in (baseline, conditional)])
    edges = np.r_[t[0], (t[:-1]+t[1:])/2, t[-1]]
    axes[3].pcolormesh(edges, [-.5, .5, 1.5], states, cmap=ListedColormap(['#F0C7C4', AMBER, GREEN]), vmin=0, vmax=2, shading='flat')
    axes[3].set_yticks([0, 1], ['原角度映射', '条件工作空间']); axes[3].invert_yaxis()
    axes[3].set_xlabel('时间（秒）'); axes[3].set_xlim(t[0], t[-1])
    fig.legend(handles=[Patch(color=GREEN, label='电机范围内可用'), Patch(color=AMBER, label='几何有解、实际电机限位不通过'), Patch(color='#F0C7C4', label='几何无解')],
               ncol=3, loc='lower center', bbox_to_anchor=(.5, .04), fontsize=10)
    fig.suptitle('同一人手 Mapping、同一 u1/u2/u3：条件工作空间改变实际请求角度', fontsize=16)
    fig.text(.5, .01, '599/599 几何有解；549/599 电机可用。未开启投影、滤波、fallback 或硬件输出。', ha='center', fontsize=11)
    fig.tight_layout(rect=[0, .09, 1, .96])
    for ext in ('png', 'svg'): fig.savefig(HERE/f'teleop_01_workspace_conditional_comparison.{ext}', dpi=160, bbox_inches='tight')
    plt.close(fig)
    print(json.dumps({k: summary[k] for k in ('projection_frames', 'core_success_frames_with_default_0_1000_bounds',
                    'core_selected_frames_with_actual_motor_limits', 'some_valid_branch_but_selected_branch_rejected_frames', 'phases')}, ensure_ascii=False))


if __name__ == '__main__': main()
