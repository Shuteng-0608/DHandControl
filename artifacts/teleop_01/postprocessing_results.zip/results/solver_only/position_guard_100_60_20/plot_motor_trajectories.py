"""Plot the recorded position-only guard experiment without running hardware."""

import json
from collections import Counter
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "DHandControl/scripts"))
from mh6_palm_calibration import PALM_MOTOR_SAFE_LIMITS, PALM_NEUTRAL_MOTORS

SOURCE = ROOT / "results/solver_only/teleop_01_position_guard_100_60_20.jsonl"
OUT = Path(__file__).resolve().parent
rows = [json.loads(line) for line in SOURCE.read_text().splitlines()]
t = np.array([row["timestamp"] for row in rows])
output = np.rint([row["control"]["selected_motor"] for row in rows]).astype(int)
previous = np.vstack((PALM_NEUTRAL_MOTORS, output[:-1]))
steps = output - previous
caps = np.array(rows[0]["solver"]["max_motor_step"])
candidate = np.full(output.shape, np.nan)
delta = np.full(output.shape, np.nan)
status = np.array([row["solver"]["status"] for row in rows])
for i, row in enumerate(rows):
    d = row["solver"]["candidate_motor_position_delta"]
    if d is not None:
        delta[i] = d
        candidate[i] = previous[i] + d
        assert any(np.array_equal(np.rint(c), candidate[i]) for c in row["solver"]["candidates"])
    assert np.array_equal(output[i], np.rint(row["solver"]["selected_motor"]))
assert np.all(np.abs(steps) <= caps)
assert np.all(np.diff(t) > 0)

font_path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc"
fontManager.addfont(font_path)
plt.rcParams.update({"font.family": FontProperties(fname=font_path).get_name(),
                     "axes.unicode_minus": False, "font.size": 11,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "svg.fonttype": "none"})
blue, gray, orange, red = "#1466B8", "#697582", "#EA9539", "#CE5362"
state = np.where(status == "SELECTED", 0,
                 np.where(np.char.find(status, "JUMP_REJECTED") >= 0, 1, 2))
edges = np.r_[t, t[-1] + np.median(np.diff(t))]
transitions = np.r_[0, np.flatnonzero(np.diff(state)) + 1, len(rows)]
phase_boundaries = (9.5, 17.5, 25.5)
phases = [(0, 9.5, "前三次握拳"), (9.5, 17.5, "四种对指"),
          (17.5, 25.5, "后三次握拳"), (25.5, t[-1], "收尾")]
names = ["M1 · 大拇指驱动 α3", "M2 · 上下翻折驱动 α2", "M3 · 闭环驱动 α1"]

def decorate(ax):
    ax.set_xlim(0, t[-1])
    ax.set_xticks(np.arange(0, 31, 2))
    ax.grid(axis="both", alpha=.17)
    for boundary in phase_boundaries:
        ax.axvline(boundary, color="#697582", ls=":", lw=.9, alpha=.8)

fig, axes = plt.subplots(4, 1, figsize=(15, 10.5), sharex=True,
                         gridspec_kw={"height_ratios": [3, 3, 3, .75]})
for j, ax in enumerate(axes[:3]):
    for a, b in zip(transitions[:-1], transitions[1:]):
        if state[a] != 0:
            ax.axvspan(edges[a], edges[b], color=(orange if state[a] == 1 else red), alpha=.095, lw=0)
    ax.plot(t, candidate[:, j], color=gray, lw=1.05, ls="--", alpha=.9)
    ax.step(t, output[:, j], where="post", color=blue, lw=1.7)
    lo, hi = PALM_MOTOR_SAFE_LIMITS[j + 1]
    ax.axhline(lo, color=red, ls=":", lw=.9)
    ax.axhline(hi, color=red, ls=":", lw=.9)
    ax.set_ylim(lo - (hi - lo) * .07, hi + (hi - lo) * .1)
    ax.set_ylabel(names[j] + "\n电机位置单位")
    ax.text(.99, .91, f"实际限位 [{lo}, {hi}]   单帧位置阈值 {caps[j]:g}",
            transform=ax.transAxes, ha="right", va="top", fontsize=10)
    decorate(ax)
for a, b in zip(transitions[:-1], transitions[1:]):
    axes[3].axvspan(edges[a], edges[b], color=[blue, orange, red][state[a]], lw=0)
axes[3].set_yticks([])
axes[3].set_ylabel("帧状态")
axes[3].set_ylim(0, 1)
for start, end, label in phases:
    axes[3].text((start + end) / 2, -.75, label, ha="center", fontsize=10)
decorate(axes[3])
axes[3].grid(False)
axes[3].set_xlabel("录制时间（秒）", labelpad=28)
legend = [Line2D([0], [0], color=blue, lw=1.7, label="保护后整数输出（离线预览）"),
          Line2D([0], [0], color=gray, ls="--", label="本帧候选目标（包含被拒绝的目标）"),
          Patch(facecolor=orange, alpha=.45, label="位置跳变保持 · 360 帧"),
          Patch(facecolor=red, alpha=.45, label="无限位内候选 · 50 帧")]
fig.suptitle("三个电机的位置轨迹：位置跳变保护 [100, 60, 20]", y=.985, fontsize=17)
fig.text(.5, .95, "599 帧 / 29.99 秒 · workspace_conditional · 关闭低通、输入限速和速度门限 · 189 帧接受新位置",
         ha="center", fontsize=10.5, color="#53606D")
fig.legend(handles=legend, loc="upper center", bbox_to_anchor=(.5, .933), ncol=2,
           frameon=False, fontsize=10)
fig.text(.5, .015, "M3 为 α1 电机驱动量；左右翻折 θ1 由闭环机构共同决定。灰线断开处没有限位内候选。动作分段为近似时间窗口。",
         ha="center", fontsize=9.5, color="#53606D")
fig.subplots_adjust(top=.865, bottom=.12, hspace=.18, left=.12, right=.98)
for suffix in ("png", "svg"):
    fig.savefig(OUT / f"motor_positions.{suffix}", dpi=180, facecolor="white")
plt.close(fig)

fig, axes = plt.subplots(3, 1, figsize=(15, 9), sharex=True)
for j, ax in enumerate(axes):
    ax.plot(t, np.abs(delta[:, j]), color=gray, lw=1.15)
    ax.plot(t, np.abs(steps[:, j]), color=blue, lw=1.2)
    ax.axhline(caps[j], color=orange, ls="--", lw=1.2)
    ax.set_ylabel(f"M{j+1} 位置变化绝对值\n电机位置单位")
    ax.set_ylim(bottom=-2)
    decorate(ax)
axes[-1].set_xlabel("录制时间（秒）")
axes[0].legend(["候选目标相对上次输出的位置差", "保护后输出的位置变化", "位置阈值"],
               loc="upper right", fontsize=9)
fig.suptitle("位置差诊断：任何一台电机超阈值，整组输出保持", fontsize=16)
fig.tight_layout(rect=[0, 0, 1, .96])
for suffix in ("png", "svg"):
    fig.savefig(OUT / f"motor_position_steps.{suffix}", dpi=180, facecolor="white")
plt.close(fig)

summary = {"source": str(SOURCE), "frames": len(rows), "duration_seconds": float(t[-1]),
           "position_threshold_M1_M2_M3": caps.tolist(),
           "status_counts": dict(Counter(status.tolist())),
           "motor_order": names, "output_min": output.min(axis=0).tolist(),
           "output_max": output.max(axis=0).tolist(),
           "max_abs_output_step_including_startup": np.max(np.abs(steps), axis=0).tolist(),
           "all_output_steps_within_thresholds": True,
           "candidate_curve": "Chosen candidate for an accepted or position-rejected frame, rounded to command units; gaps when no actual-limit candidate exists."}
(OUT / "plot_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(summary, ensure_ascii=False))
