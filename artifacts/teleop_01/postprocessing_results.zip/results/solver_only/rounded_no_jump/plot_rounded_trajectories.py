"""Plot rounded MH6 motor targets with no position or speed rejection."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "DHandControl/scripts"))
from mh6_palm_calibration import PALM_MOTOR_SAFE_LIMITS, PALM_NEUTRAL_MOTORS
from mh6_palm_solution_selector import PalmSolutionSelector

SOURCE = ROOT / "results/solver_only/teleop_01_workspace_conditional.jsonl"
OUT = Path(__file__).resolve().parent
LOG = ROOT / "results/solver_only/teleop_01_workspace_conditional_rounded_no_jump.jsonl"
rows = [json.loads(line) for line in SOURCE.read_text().splitlines() if line.strip()]
distance = PalmSolutionSelector()._distance  # Only the calibrated metric; never call select().
reference = list(PALM_NEUTRAL_MOTORS)
frames = []
for row in rows:
    valid = [(i, candidate) for i, candidate in enumerate(row["solver"]["candidates"])
             if PalmSolutionSelector._is_valid_solution(candidate)]
    if valid:
        index, selected = min(valid, key=lambda item: distance(item[1], reference))
        reference = list(selected)
        status = "SELECTED"
    else:
        index, status = None, "HELD_NO_VALID_SOLUTION"
    integer = [int(round(value)) for value in reference]
    assert all(lo <= x <= hi for x, (lo, hi) in zip(integer, PALM_MOTOR_SAFE_LIMITS.values()))
    frames.append({"frame_index": row["frame_index"], "timestamp": row["timestamp"],
                   "motor_order": [1, 2, 3], "solver_input": row["solver"]["input"],
                   "selected_candidate_index": index,
                   "valid_motor_candidate_count": len(valid), "status": status,
                   "selected_motor_float": list(reference), "rounded_motor": integer})

audit_path = ROOT / "results/trajectory_audit/teleop_01_workspace_conditional/frames.jsonl"
matched_audit = None
if audit_path.exists():
    audit = [json.loads(line) for line in audit_path.read_text().splitlines()]
    assert len(audit) == len(frames)
    assert np.allclose([r["bound_valid_reference_motor"] for r in audit],
                       [r["selected_motor_float"] for r in frames], atol=1e-8, rtol=0)
    matched_audit = True
LOG.write_text("".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in frames))

t = np.array([row["timestamp"] for row in frames])
floating = np.array([row["selected_motor_float"] for row in frames])
integer = np.array([row["rounded_motor"] for row in frames])
held = np.array([row["status"] != "SELECTED" for row in frames])
steps = np.diff(np.vstack((PALM_NEUTRAL_MOTORS, integer)), axis=0)
assert np.all(np.diff(t) > 0)
assert np.max(np.abs(integer - floating)) <= .5 + 1e-12

font_path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc"
fontManager.addfont(font_path)
plt.rcParams.update({"font.family": FontProperties(fname=font_path).get_name(),
                     "axes.unicode_minus": False, "font.size": 11,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "svg.fonttype": "none"})
blue, gray, red = "#1466B8", "#798591", "#C9475B"
motor_names = ["M1 · 大拇指驱动 α3", "M2 · 上下翻折驱动 α2", "M3 · 闭环驱动 α1"]
edges = np.r_[t, t[-1] + np.median(np.diff(t))]
transitions = np.r_[0, np.flatnonzero(np.diff(held.astype(int))) + 1, len(t)]
fig, axes = plt.subplots(3, 1, figsize=(15, 9.5), sharex=True)
for j, ax in enumerate(axes):
    for start, end in zip(transitions[:-1], transitions[1:]):
        if held[start]:
            ax.axvspan(edges[start], edges[end], color=red, alpha=.14, lw=0)
    ax.plot(t, floating[:, j], color=gray, ls="--", lw=1, alpha=.85, zorder=2)
    ax.step(t, integer[:, j], where="post", color=blue, lw=1.45, zorder=3)
    low, high = PALM_MOTOR_SAFE_LIMITS[j + 1]
    ax.axhline(low, color=red, ls=":", lw=.9)
    ax.axhline(high, color=red, ls=":", lw=.9)
    ax.set_ylim(low - (high-low)*.07, high + (high-low)*.10)
    ax.set_ylabel(motor_names[j] + "\n电机位置单位")
    ax.text(.99, .91, f"实际限位 [{low}, {high}]", ha="right", va="top", fontsize=10,
            transform=ax.transAxes)
    ax.set_xlim(0, t[-1])
    ax.set_xticks(np.arange(0, 31, 2))
    ax.grid(alpha=.18)
    for boundary in (9.5, 17.5, 25.5):
        ax.axvline(boundary, color=gray, ls=":", lw=.9)
phases = [(0, 9.5, "前三次握拳"), (9.5, 17.5, "四种对指"),
          (17.5, 25.5, "后三次握拳"), (25.5, t[-1], "收尾")]
for start, end, label in phases:
    axes[-1].text((start+end)/2, -.19, label, ha="center", fontsize=10,
                  transform=axes[-1].get_xaxis_transform())
axes[-1].set_xlabel("录制时间（秒）", labelpad=31)
fig.suptitle("三个电机取整后的轨迹 · 无跳变限制", fontsize=18, y=.985)
fig.text(.5, .947, "599 帧 / 29.99 秒 · workspace_conditional · 原始 Mapping 输入 · 无低通、输入限速、速度门限和位置跳变门限",
         ha="center", fontsize=10.5, color="#53606D")
fig.legend(handles=[Line2D([0], [0], color=blue, lw=1.5, label="取整后的电机位置"),
                    Line2D([0], [0], color=gray, ls="--", label="取整前的位置（通常与蓝线重合）"),
                    Patch(facecolor=red, alpha=.25, label=f"无限位内候选：保持上一位置 · {held.sum()} 帧")],
           loc="upper center", bbox_to_anchor=(.5, .925), ncol=3, frameon=False, fontsize=10)
fig.text(.5, .013, "仅做限位内最近分支选择和整数取整；未进行取整后模型复算。M3 为 α1 驱动量，θ1 由闭环关系决定。动作分段为近似窗口。",
         ha="center", fontsize=9.5, color="#53606D")
fig.subplots_adjust(top=.85, bottom=.13, hspace=.22, left=.12, right=.98)
for suffix in ("png", "svg"):
    fig.savefig(OUT / f"motor_positions_rounded_no_jump.{suffix}", dpi=180, facecolor="white")
plt.close(fig)

summary = {"source_log": str(SOURCE), "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
           "frames": len(frames), "duration_seconds": float(t[-1]),
           "mapping_mode": "workspace_conditional", "mapping_input": "raw",
           "lowpass_enabled": False, "input_slew_enabled": False,
           "position_jump_guard_enabled": False, "speed_guard_enabled": False,
           "rounded_model_validation_used_as_gate": False, "actual_motor_limits_applied": True,
           "branch_selection": "Nearest actual-limit-valid candidate relative to previous accepted float target, using existing calibrated motor distance; start reference [247,500,500].",
           "status_counts": dict(Counter(row["status"] for row in frames)),
           "motor_order": motor_names, "minimum_integer_position": integer.min(axis=0).tolist(),
           "maximum_integer_position": integer.max(axis=0).tolist(),
           "max_abs_integer_step_including_startup": np.abs(steps).max(axis=0).tolist(),
           "max_abs_rounding_error": np.abs(integer-floating).max(axis=0).tolist(),
           "matches_previous_no_jump_reference": matched_audit,
           "rounded_frame_log": str(LOG)}
(OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(summary, ensure_ascii=False))
